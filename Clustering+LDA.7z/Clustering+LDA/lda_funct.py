import re
import gensim
import gensim.corpora as corpora
from gensim.utils import simple_preprocess


def LDA(text):

    data = text
    data = [re.sub('\s+', ' ', str(sent)) for sent in data]
    data = [re.sub("\'", "", sent) for sent in data]

    from nltk.corpus import stopwords
    stop_words = stopwords.words('english')

    def sent_to_words(sentences):
        for sentence in sentences:
            yield (gensim.utils.simple_preprocess(str(sentence), deacc=True))
    data_words = list(sent_to_words(data))

    def remove_stopwords(texts):
        return [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts]
    data_words_nostops = data_words
    data_words_nostops = remove_stopwords(data_words_nostops)
    bigram = gensim.models.Phrases(data_words_nostops, min_count=1, threshold=100)  # higher threshold fewer phrases.

    bigram_mod = gensim.models.phrases.Phraser(bigram)

    def make_bigrams(texts):
        return [bigram_mod[doc] for doc in texts]

    data_words_bigrams = make_bigrams(data_words_nostops)

    data_lemmatized = remove_stopwords(data_words_bigrams)

    id2word = corpora.Dictionary(data_lemmatized)

    texts = data_lemmatized
    corpus = [id2word.doc2bow(text) for text in texts]

    lda_model = gensim.models.LdaMulticore(corpus=corpus,
                                           id2word=id2word,
                                           random_state=100,
                                           num_topics=1,
                                           passes=10,
                                           per_word_topics=True,
                                           workers=4)
    return lda_model.print_topics(num_words=5)
