"""
Created on Fri Sep 20 10:57:21 2019

@author: amehra
"""

from nltk.corpus import stopwords
import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
from numpy import linalg as LA
from flask import jsonify


class Lingo:
    """This Class helps in creating object for Lingo based clustrering."""
    # this class lingo clusters text based on lingo research paper
    def __init__(self, data_file, cluster, sub_cluster, column_name):
        """
        :param excel_file: data file to perform clustering
        :param num_cluster: number of clusters
        :param subcluster: number of sub-clusters
        """
        self.data_file = data_file
        self.cluster = cluster
        self.sub_cluster = sub_cluster
        self.column_name = column_name
    # cluster_names = ''
    # c_vec = ''
    # Cluster_Prediction_Matrix = ''
    # custer_pedict_matrix = ''
    # prediction_dataframe = ''
    # Lingo_Clustering_Predict = ''
    # Lingo_Clustering_Predict1 = ''

    def make_cluster_lingo(self):
        """This function creates clusters"""
# this class lingo clusters text based on lingo research paper
        global cluster_names
        global c_vec
        global Cluster_Prediction_Matrix
        global custer_pedict_matrix
        global prediction_dataframe
        global Lingo_Clustering_Predict
        global Lingo_Clustering_Predict1


#        print("data_file", type(data_file), data_file)
        df_data = self.data_file
        try:
            df_data = df_data[self.column_name].values.tolist()
        except Exception:
            return jsonify({"Error": "Column not present"})
    #    print(pd.DataFrame(data_file))

        stop_words = stopwords.words('english')
        c_vec = TfidfVectorizer(
            ngram_range=(
                1,
                3),
            stop_words=stop_words,
            max_df=.1,
            max_features=11000)

        # input to fit_transform() should be an iterable with strings
        ngrams = c_vec.fit_transform(df_data)

        # needs to happen after fit_transform()
#        vocab = c_vec.vocabulary_
        count_vect_df = pd.DataFrame(
            ngrams.toarray(),
            columns=c_vec.get_feature_names())

        n_cluster = int(self.cluster) + int(self.cluster) * .8
#        print(int(n_cluster))
        svd_element = TruncatedSVD(n_components=int(n_cluster), n_iter=100)
        svd_element.fit(count_vect_df)

        # svd_element.components_[0]
        # best_svd_index = np.argmax(svd_element.components_[0], axis=0)
        # c_vec.get_feature_names()[best_svd_index]
        cluster_names = []
        best_svd_index = []

        for i in range(0, len(svd_element.components_ + 1)):
            index = np.argmax(svd_element.components_[i], axis=0)
#                         print(index)
            best_svd_index.append(index)
            a = c_vec.get_feature_names()[index]
            cluster_names.append(a)

        def cluster_optimization(cluster_names):
            mylist = cluster_names.copy()
#            print(len(mylist))
            cluster_name = []
        # cluster_name = [cluster_name.append(x) for x in mylist if x not in cluster_name]
            for name in mylist:
                if name not in cluster_name:
                    cluster_name.append(name)
            return cluster_name

        cluster_names = cluster_optimization(cluster_names)
        cluster_names = cluster_names[:int(self.cluster)]
        print('new clusters : ', cluster_names)

        cosine_similarity_matrix = cosine_similarity(
            np.transpose(ngrams.toarray()))

        custer_pedict_matrix = []
        for i in cluster_names:
            index = c_vec.get_feature_names().index(i)
#            a = []
#            a = cosine_similarity_matrix[index]
            custer_pedict_matrix.append(cosine_similarity_matrix[index])
        custer_pedict_matrix = np.asarray(custer_pedict_matrix)

        def Lingo_Clustering_Predict(text, custer_pedict_matrix):
            new_matrix = np.transpose(c_vec.transform(text).toarray())
            prediction = np.dot(custer_pedict_matrix, new_matrix)
            norm = LA.norm(prediction, ord='fro')
            prediction_matrix = prediction / norm
            #print(cluster_names[np.argmax(prediction_matrix)], np.max(prediction_matrix))

            return cluster_names[np.argmax(prediction_matrix)], np.max(
                prediction_matrix)

        cluster_data = pd.DataFrame(data=df_data, columns=[str(self.column_name)])
        data = cluster_data
        data["prediction"] = ""
        data["prediction confidence"] = ""

        for i in range(0, len(data[str(self.column_name)])):
            cluster_name, confidece_score = Lingo_Clustering_Predict(
                [data[str(self.column_name)][i]], custer_pedict_matrix)
            data["prediction"][i] = cluster_name
            data["prediction confidence"][i] = confidece_score

        def text_Vectorization_using_TfiDF(data_input):

            c_vec1 = TfidfVectorizer(
                ngram_range=(
                    2,
                    2),
                stop_words=stop_words,
                max_features=11000,
                token_pattern=r'[A-Za-z][\w\-]*')

            # input to fit_transform() should be an iterable with strings
            #ngrams = c_vec.fit_transform([test_str1,test_str2])
            ngrams = c_vec1.fit_transform(data_input)

            # needs to happen after fit_transform()
#            vocab = c_vec1.vocabulary_
#
#            count_values = ngrams.toarray().sum(axis=0)
            return c_vec1, ngrams

        def cluster_names_by_SVD(ngrams, c_vec, N):

            count_vect_df1 = pd.DataFrame(
                ngrams.toarray(), columns=c_vec.get_feature_names())
            #print(N)
            sub_n_cluster = int(N) + int(N) * .8
#            print(int(sub_n_cluster))
            svd_element = TruncatedSVD(
                n_components=int(sub_n_cluster), n_iter=100)
            svd_element.fit(count_vect_df1)
            # svd_element.components_[0]
            # best_svd_index = np.argmax(svd_element.components_[0], axis=0)
            # c_vec.get_feature_names()[best_svd_index]
            cluster_names = []
            best_svd_index = []
            for i in range(0, len(svd_element.components_ + 1)):
                index = np.argmax(svd_element.components_[i], axis=0)
#                            print(index)
                best_svd_index.append(index)
#                a = c_vec.get_feature_names()[index]
                cluster_names.append(c_vec.get_feature_names()[index])
            return cluster_names

        def Cosine_Similarity(ngrams1):
            # ------------------------------ Cosine Similarity Matrix

            cosine_similarity_matrix1 = cosine_similarity(
                np.transpose(ngrams1.toarray()))
            #count_vect_cosine_similarity_df = pd.DataFrame(x)
            # print(count_vect_cosine_similarity_df)
            np.shape(cosine_similarity_matrix1)
            return cosine_similarity_matrix1

        def Cluster_Prediction_Matrix(
                c_vec1,
                cosine_similarity_matrix1,
                cluster_names1):
            custer_pedict_matrix1 = []
            for i in cluster_names1:
                print("cluster_name:", i)
                index = c_vec1.get_feature_names().index(i)

                custer_pedict_matrix1.append(cosine_similarity_matrix1[index])
            custer_pedict_matrix1 = np.asarray(custer_pedict_matrix1)
            return custer_pedict_matrix1

        def Lingo_Clustering_Predict1(
                text,
                custer_pedict_matrix1,
                c_vec1,
                cluster_names1):
            #            print('lingo cluster names:', cluster_names1)
            new_matrix1 = np.transpose(c_vec1.transform(text).toarray())
            prediction1 = np.dot(custer_pedict_matrix1, new_matrix1)
            norm1 = LA.norm(prediction1, ord='fro')
            prediction_matrix1 = prediction1 / norm1
            #print(cluster_names[np.argmax(prediction_matrix)], np.max(prediction_matrix))

            return cluster_names1[np.argmax(prediction_matrix1)], np.max(
                prediction_matrix1)

        def Cluster_dataframe_with_prediction(
                data1, custer_pedict_matrix1, c_vec1, cluster_names1):
            #     cluster_data =  pd.DataFrame(data=data)
            #     data1 = data
            data1["prediction1"] = ""
            data1["prediction confidence1"] = ""

            for i in range(0, len(data1[str(self.column_name)])):
                cluster_name1, confidece_score1 = Lingo_Clustering_Predict1(
                    [data1[str(self.column_name)][i]], custer_pedict_matrix1, c_vec1, cluster_names1)
#                print('cluster_name : ', cluster_name1,confidece_score1)
                data1["prediction1"][i] = cluster_name1
                data1["prediction confidence1"][i] = confidece_score1
            return data1
        # ---------------Running Hierarcy for Code Lingo

        df = pd.DataFrame()
        prediction_dataframe = pd.DataFrame()
        prediction_list = []
        for i in set(cluster_names):
            #            print(i)
            data1 = data.loc[data['prediction'] == str(i)]
        #     print(data1)
            data1 = data1.reset_index(drop=True)
            c_vec1, ngrams1 = text_Vectorization_using_TfiDF(data1[str(self.column_name)])
        #     print(c_vec1.vocabulary_)
    #        sub_clusters = cluster_optimization(cluster_names)

            cluster_names1 = cluster_names_by_SVD(ngrams1, c_vec1, self.sub_cluster)
            cluster_names1 = cluster_names1[:int(self.sub_cluster)]
#            print('cluster names', cluster_names1)
            cosine_similarity_matrix1 = Cosine_Similarity(ngrams1)
        #     print('length', len(cosine_similarity_matrix1))
            custer_pedict_matrix1 = Cluster_Prediction_Matrix(
                c_vec1, cosine_similarity_matrix1, cluster_names1)
            datai = Cluster_dataframe_with_prediction(
                data1, custer_pedict_matrix1, c_vec1, cluster_names1)
            prediction_list.append(
                [i, c_vec1, custer_pedict_matrix1, cluster_names1])
            df = df.append(datai, ignore_index=True)
#            print(len(df))
            prediction_dataframe = pd.DataFrame(
                prediction_list,
                columns=[
                    'clusternames',
                    'tfidf_object',
                    'custer_pedict_matrix',
                    'subclusternames'])

        df_json = df[[str(self.column_name),'prediction', 'prediction1']]
        df_json['counts'] = 1
    #    group = df_json.groupby('prediction')
    #    df2 = group.apply(lambda x: x['prediction1'].unique())
    #    json_output = df2.to_json()

        json_output = {}
        # for i in df_json['prediction'].unique():
        #     json_output[i] = df_json[df_json['prediction'] == i].pivot_table(
        #         index=['prediction1'], aggfunc='count', values='counts').to_dict()['counts']
        for i in df_json['prediction'].unique():
            for j in df_json['prediction1'][df_json['prediction'] == i].unique():
                json_output[i] = {j: list(df_json[str(self.column_name)][df_json['prediction1'] == j].values)}

        return jsonify(json_output)


class Lingopredict:
    """
    """

    def __init__(self, predict_text):
        """
        :param predict_text
        """
        self.predict_text = predict_text

    def lingo_prediction(self):
        """This function predicts clusters"""

        #        predict_text = request.form["predict_text"]

        prediction_cluster = Lingo_Clustering_Predict(
            [self.predict_text], custer_pedict_matrix)
        predict_list_data = prediction_dataframe.loc[prediction_dataframe['clusternames']
                                                     == prediction_cluster[0]].values.tolist()
        c_vec1 = predict_list_data[0][1]
        custer_pedict_matrix1 = predict_list_data[0][2]
        cluster_names1 = predict_list_data[0][3]
        prediction_sub_cluster = Lingo_Clustering_Predict1(
            [self.predict_text], custer_pedict_matrix1, c_vec1, cluster_names1)

        return jsonify(prediction_cluster[0], prediction_sub_cluster[0])

