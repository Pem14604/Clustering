
"""
@author: amsapra
"""
import re
import string
import logging
import nltk
import json
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
from flask import jsonify
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import AgglomerativeClustering
from sklearn.feature_extraction.text import TfidfVectorizer
import lda_funct


logging.basicConfig(filename='./app.log')

class Agglomerative:
    """
    Agglomerative clustering
    """
    logging.basicConfig(filename='./app.log')

    def __init__(self, excel_file, num_cluster, subcluster, column_name, usecase):
        """
        :param excel_file: data file to perform clustering
        :param num_cluster: number of clusters
        :param subcluster: number of sub-clusters
        """
        self.excel_file = excel_file
        self.num_cluster = num_cluster
        self.subcluster = subcluster
        self.column_name = column_name
        self.usecase = usecase
    def agglomerative_clustering_keywords(self):
        """

        :return: json of clustered data
        """

        # pre-processing
        stoplist = list(string.punctuation)
        stoplist += stopwords.words('english')
        stoplist += ['not', 'should', 'would', 'will', 'can', 'could']
        data = self.excel_file
        try:
            data = data[self.column_name].values.tolist()
        except Exception:
            return jsonify({"Error": "Column not present"})
        final_list = []
        for i in data:
            review = re.sub(r'^br$', ' ', str(i))
            review = review.lower()
            review = re.sub(r'\s+br\s+', ' ', review)
            review = re.sub(r'[^\w\s]', ' ', review)
            review = re.sub(r'_', ' ', review)
            review = re.sub(r'\s+[a-z]\s+', ' ', review)
            review = re.sub(r'^b\s+', '', review)
            review = re.sub(r'\s+', ' ', review)
            review = re.sub(r'\d+', '', review)
            words = nltk.word_tokenize(review)
            words = [word for word in words if word not in stoplist]
            words = [WordNetLemmatizer().lemmatize(word) for word in words]
            final = " ".join(words)
            final_list.append(final)

        # tf-idf

        vectorizer = TfidfVectorizer(max_features=7000, stop_words='english')
        vectorizer_sub = TfidfVectorizer(max_features=7000, stop_words='english')
        model = AgglomerativeClustering(n_clusters=int(self.num_cluster), affinity='euclidean',
                                        linkage='ward')
        model_sub = AgglomerativeClustering(n_clusters=int(self.subcluster), affinity='euclidean',
                                            linkage='ward')
        try:
            tfidf = vectorizer.fit_transform(final_list).toarray()
            dist = 1 - cosine_similarity(tfidf)
            # agglomerative on the data
            model.fit(dist)
            cluster_dict = {}
            for i in enumerate(final_list):
                cluster_dict.setdefault(str(model.labels_[i[0]]), []).append(final_list[i[0]])
            keywords = []
            for key1, value1 in cluster_dict.items():
                x = lda_funct.LDA(text=value1)
                review = re.sub(r'\d+', '', x[0][1])
                review = re.sub(r'[^\w]', ' ', review)
                review = " ".join(review.split())
                # print(review)
                keywords.append(review)
            # cluster_list = []
            # for i in model.labels_:
            #     cluster_list.append(keywords[i])
            final_cluster_dict = {}
            for k, value in cluster_dict.items():
                sub_cluster_dict = {}
                tfidf_sub = vectorizer_sub.fit_transform(value).toarray()
                sub_dist = 1 - cosine_similarity(tfidf_sub)
                model_sub.fit(sub_dist)
                for i in enumerate(value):
                    sub_cluster_dict.setdefault(str(model_sub.labels_[i[0]]), []). \
                        append(value[i[0]])
                for keys, values in sub_cluster_dict.items():
                    for i in lda_funct.LDA(text=values):
                        review = re.sub(r'\d+', '', i[1])
                        review = re.sub(r'[^\w]', ' ', review)
                        review = " ".join(review.split())
                    if review in sub_cluster_dict.keys():
                        sub_cluster_dict[keys] = sub_cluster_dict.pop(keys)
                    else:
                        sub_cluster_dict[review] = sub_cluster_dict.pop(keys)
                final_cluster_dict.update({str(k): sub_cluster_dict})
            major_dict = {}
            final_values = list(final_cluster_dict.values())
            for i, j in zip(keywords, final_values):
                major_dict.update({i: j})
            print(major_dict)
            count_dict = {}
            for key, value in major_dict.items():
                temp_dict = {}
                for fink, finv in value.items():
                    temp_dict.update({str(fink): finv})
                count_dict.update({str(key): temp_dict})
            # # retjson = {"clustered_data": final_cluster_dict}
            # # retjson = {"ClusterCount":count_dict}
            print(count_dict)
            # print(self.excel_file)
            # self.excel_file['Cluster'] = cluster_list
            cluster_list =[]
            sub_cluster_list = []

            for k,v in count_dict.items():
                for key, value in v.items():
                    for i in value:
                        cluster_list.insert(final_list.index(i), k)
                        sub_cluster_list.insert(final_list.index(i), key)
            self.excel_file['Cluster'] = cluster_list
            self.excel_file['SubCluster'] = sub_cluster_list
            with open("./config.json", 'r') as f:
                excel_file = json.load(f)
            self.excel_file.to_csv(excel_file['file']+str(self.usecase)+"_cleaned_file_clustered.csv")

            #df1.to_excel("output.xlsx")
            return jsonify(count_dict)
        except Exception as E:
            logging.exception(E)
            message = "Algorithm Failed"
            return jsonify({"Error": message, "Exception": str(E)}), 400
