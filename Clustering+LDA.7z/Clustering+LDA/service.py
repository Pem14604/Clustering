"""
@author: Vsolanki/amsapra
"""
if __name__ == '__main__':
    import json
    import logging
    import pandas as pd
    from flask import Flask, request, jsonify
    import kmeans_sta
    import agglomerative_sta
    import gmm_sta
    import lingo_sta

    APP = Flask(import_name="Clustering")


    @APP.route("/get_clusters", methods=['POST'])
    def get_clusters():
        """

        :return:
        """
        logging.basicConfig(filename='./app.log')
        # logging = logging.getLogger()

        try:
            point = request.json
            print(point)
            column_name = point['column']
            algo = point['algorithm']
            cluster = point['clusters']
            usecase = point['usecase']
            subcluster = point['sub_clusters']
        except Exception as E:
            print(str(E))

            logging.exception(str(E))
            return jsonify({"Error": str(E), "Exception": str(E)}), 400

        try:
            with open("./config.json", 'r') as f:
                excel_file = json.load(f)
            d_f = pd.read_excel(excel_file['file']+str(usecase)+"_cleaned_file.xlsx")
            logging.info("Reading File")

        except Exception as E:
            message = "File Not Found"

            return jsonify({"Error": message, "Exception": str(E)}), 400

        if algo.lower() == 'kmeans':

            kmeans_obj = kmeans_sta.Kmeans(d_f, cluster, subcluster, column_name, usecase)
            solution = kmeans_obj.kmeans_clustering_keywords()

        elif algo.lower() == 'agglomerative':

            agglo_obj = agglomerative_sta.Agglomerative(d_f, cluster, subcluster, column_name, usecase)
            solution = agglo_obj.agglomerative_clustering_keywords()

        elif algo.lower() == 'gmm':

            gmm_obj = gmm_sta.Gmm(d_f, cluster, subcluster, column_name, usecase)
            solution = gmm_obj.gmm_clustering_keywords()

        elif algo.lower() == 'lingo':

            lingo_obj = lingo_sta.Lingo(d_f, cluster, subcluster, column_name)
            solution = lingo_obj.make_cluster_lingo()

        else:

            logging.error("Algorithm not supported")
            solution = jsonify({"Error": "Clustering Failed ", "Exception":
                                "Supported Algorithms: K-means, Agglomerative,"
                                " Lingo and GMM but entered: " + algo}), 400
        logging.info("Clustering Completed")
        return solution


    @APP.route("/predict", methods=['POST'])
    def predict():
        """

        :return:
        """
        logging.basicConfig(filename='./app.log')
        try:
            point = request.json
            predict = point['predict']
            algo = point['algorithm']
            logging.info("Reading data to perform prediction and algo selection")
        except Exception as E:
            print(str(E))

            logging.exception(str(E))
            return jsonify({"Error": str(E) + "Not Found", "Exception": str(E)}), 400
        try:
            if algo.lower() == 'kmeans':

                kmeans_obj = kmeans_sta.Kmeanspredict(predict_text=predict)
                predicted = kmeans_obj.kmeans_predict_keywords()
                # return predicted

            elif algo.lower() == 'gmm':

                gmm_obj = gmm_sta.Gmmpredict(predict_text=predict)
                predicted = gmm_obj.gmm_predict_keywords()

            elif algo.lower() == 'lingo':

                lingo_obj = lingo_sta.Lingopredict(predict_text=predict)
                predicted = lingo_obj.lingo_prediction()
            else:
                predicted = jsonify({"Error": "Prediction Failed ",
                                     "Exception": "Model is not trained on " + algo + "."}), 400
            logging.info("Prediction completed")

            return predicted
        except Exception as E:
            predicted = jsonify({"Error": "Prediction Failed",
                                 "Exception": str(E)}), 400
            return predicted


    APP.run(host="10.133.6.204", port="5001", debug="True")
