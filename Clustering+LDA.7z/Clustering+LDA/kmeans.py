"""
@author: amsapra
"""
import re
import string
import logging
import nltk
import json
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from flask import jsonify
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import lda_funct


class Kmeans:
    """
    Kmeans clustering
    """


    def __init__(self, excel_file, num_cluster, subcluster, column_name, usecase):
        """
        :param excel_file: data file to perform clustering
        :param num_cluster: number of clusters
        :param subcluster: number of sub-clusters
        """
        self.excel_file = excel_file
        self.num_cluster = num_cluster
        self.subcluster = subcluster
        self.column_name = column_name
        self.usecase = usecase

    def kmeans_clustering_keywords(self):
        """

        :return: json of clustered data
        """

        global VECTORIZER
        global model_sub
        global model
        global vectorizer_sub
        global keywords
        global major_dict
        # pre-processing
        stoplist = list(string.punctuation)
        stoplist += stopwords.words('english')
        stoplist += ['not', 'should', 'would', 'will', 'can', 'could']
        lemmatizer = WordNetLemmatizer()
        data = self.excel_file
        try:
            data = data[self.column_name].values.tolist()
        except Exception:
            return jsonify({"Error": "Column not present"})
        final_list = []
        for i in data:
            review = re.sub(r'^br$', ' ', str(i))
            review = review.lower()
            review = re.sub(r'\s+br\s+', ' ', review)
            review = re.sub(r'[^\w\s]', ' ', review)
            review = re.sub(r'_', ' ', review)
            review = re.sub(r'\s+[a-z]\s+', ' ', review)
            review = re.sub(r'^b\s+', '', review)
            review = re.sub(r'\s+', ' ', review)
            review = re.sub(r'\d+', '', review)
            words = nltk.word_tokenize(review)
            words = [word for word in words if word not in stoplist]
            words = [lemmatizer.lemmatize(word) for word in words]
            final = " ".join(words)
            final_list.append(final)

        # tf-idf
        VECTORIZER = TfidfVectorizer(max_features=7000, stop_words='english')
        vectorizer_sub = TfidfVectorizer(max_features=7000, stop_words='english')
        model_sub = KMeans(n_clusters=int(self.subcluster), init='k-means++',
                           random_state=3457)


        model = KMeans(n_clusters=int(self.num_cluster), init='k-means++',
                       random_state=3457)
        try:

            tfidf = VECTORIZER.fit_transform(final_list).toarray()
            model.fit(tfidf)
            main_cluster = model.predict(tfidf)
            cluster_dict = {}
            for i, j in enumerate(final_list):
                cluster_dict.setdefault(str(main_cluster[i]), []).append(final_list[i])
            keywords = []
            for key1, value1 in cluster_dict.items():
                X = lda_funct.LDA(text=value1)
                review = re.sub(r'\d+', '', X[0][1])
                review = re.sub(r'[^\w]', ' ', review)
                review = " ".join(review.split())
                # print(review)
                keywords.append(review)
            # cluster_list = []
            # for i in model.labels_:
            #     cluster_list.append(keywords[i])
            # kmeans on the data

            final_cluster_dict = {}
            for key, value in cluster_dict.items():
                sub_cluster_dict = {}
                tfidf_sub = vectorizer_sub.fit_transform(value).toarray()
                model_sub.fit(tfidf_sub)
                sub_cluster = model_sub.predict(tfidf_sub)
                for i, j in enumerate(value):
                    sub_cluster_dict.setdefault(str(sub_cluster[i]), []).append(value[i])
                for keys, values in sub_cluster_dict.items():
                    for i in lda_funct.LDA(text=values):
                        review = re.sub(r'\d+', '', i[1])
                        review = re.sub(r'[^\w]', ' ', review)
                        review = " ".join(review.split())
                    sub_cluster_dict[review] = sub_cluster_dict.pop(keys)
                final_cluster_dict.update({str(key): sub_cluster_dict})
            major_dict = {}
            print(final_cluster_dict)
            final_values = list(final_cluster_dict.values())
            for i, j in zip(keywords, final_values):
                major_dict.update({i: j})
            print(major_dict)
            count_dict = {}
            for key, value in major_dict.items():
                temp_dict = {}
                for fink, finv in value.items():
                    temp_dict.update({str(fink): finv})
                count_dict.update({str(key): temp_dict})
            # # retjson = {"clustered_data": final_cluster_dict}
            # # retjson = {"ClusterCount":count_dict}
            print(count_dict)
            cluster_list = []
            sub_cluster_list = []


            major_cluster_list = []
            for i in model.labels_:
                major_cluster_list.append(keywords[str(i)])
            self.excel_file['Cluster'] = major_cluster_list
            with open("./config.json", 'r') as f:
                excel_file = json.load(f)
            self.excel_file.to_csv(excel_file['file'] + str(self.usecase) + "_cleaned_file_clustered.csv")
            return jsonify(count_dict)
        except Exception as E:
            logging.exception(E)
            message = "Algorithm Failed"
            return jsonify({"Error": message, "Exception": str(E)}), 400


class Kmeanspredict:
    """
    Kmeans prediction
    """

    def __init__(self, predict_text):
        """
        :param excel_file: data file to perform clustering
        :param num_cluster: number of clusters
        :param subcluster: number of sub-clusters
        """
        self.predict_text = predict_text

    def kmeans_predict_keywords(self):
        """

        :param predict_text: text on which to perform prediction
        :return:
        """
        text = [self.predict_text]
        ##prediction
        sub_clus_predict = model_sub.predict(vectorizer_sub.transform(text))
        main_clus_predict = model.predict(VECTORIZER.transform(text))
        main_cluster_predicted = keywords[int(main_clus_predict)]
        sub_clus_dict = major_dict[main_cluster_predicted]
        sub_value = list(sub_clus_dict.keys())
        sub_cluster_predicted = sub_value[int(sub_clus_predict)]
        predicted = {"Main_Cluster": str(main_cluster_predicted),
                     "Sub_cluster": str(sub_cluster_predicted)}
        print(predicted)
        return jsonify(predicted)
